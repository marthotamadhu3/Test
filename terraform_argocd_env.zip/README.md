# Terraform modular ArgoCD + environment-aware sample

This repo shows a modular, environment-aware Terraform layout that:
- Creates namespaces
- Installs ArgoCD via Helm into the namespace
- Installs Ingress controller and optional monitoring

Usage:
1. Update envs/*/terraform.tfvars with your AKS cluster name and resource group.
2. Run for a specific environment (example: dev):

   terraform init
   terraform workspace new dev || terraform workspace select dev
   terraform apply -var-file=envs/dev/terraform.tfvars

Notes:
- The code expects an existing AKS cluster. Terraform reads the AKS kubeconfig using the azurerm_kubernetes_cluster data source.
- You can extend modules/ to add storage, cert-manager, external-dns, workload-identity, etc.
